
import React, { useEffect, useState } from 'react';
import { Connection, PublicKey, clusterApiUrl } from '@solana/web3.js';

function App() {
  const [walletAddress, setWalletAddress] = useState(null);

  const connectWallet = async () => {
    if (window.solana && window.solana.isPhantom) {
      const response = await window.solana.connect();
      setWalletAddress(response.publicKey.toString());
    }
  };

  useEffect(() => {
    const checkIfWalletIsConnected = async () => {
      if (window.solana && window.solana.isPhantom) {
        const response = await window.solana.connect({ onlyIfTrusted: true });
        setWalletAddress(response.publicKey.toString());
      }
    };
    checkIfWalletIsConnected();
  }, []);

  return (
    <div>
      <h1>LangoVerse</h1>
      {walletAddress ? (
        <p>Connected wallet: {walletAddress}</p>
      ) : (
        <button onClick={connectWallet}>Connect Phantom Wallet</button>
      )}
    </div>
  );
}

export default App;
