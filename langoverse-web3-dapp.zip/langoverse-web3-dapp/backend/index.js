
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/langoverse', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const TableSchema = new mongoose.Schema({
  title: String,
  language: String,
  createdBy: String,
});

const Table = mongoose.model('Table', TableSchema);

app.get('/tables', async (req, res) => {
  const tables = await Table.find();
  res.json(tables);
});

app.post('/tables', async (req, res) => {
  const { title, language, createdBy } = req.body;
  const newTable = new Table({ title, language, createdBy });
  await newTable.save();
  res.json(newTable);
});

app.listen(4000, () => console.log('Backend running on port 4000'));
