
# LangoVerse Web3 dApp

**LangoVerse** is a decentralized Web3 platform built on Solana that empowers users around the world to engage in language exchange, live voice sessions, and cultural learning. This is a basic MVP codebase for showcasing at hackathons and Web3 events.

## Features
- Web3 login with Phantom Wallet
- Voice-based community table creation
- REST API backend using Express.js and MongoDB
- Expandable architecture for tokenomics, DAO, premium features, etc.

## Stack
- React.js
- Node.js + Express
- MongoDB
- Solana (Phantom Wallet, Web3.js)
- Anchor (for future Solana smart contracts)

## How to Run

### Frontend
```bash
cd frontend
npm install
npm start
```

### Backend
```bash
cd backend
npm install
node index.js
```

Make sure MongoDB is running locally, or connect to MongoDB Atlas.

---

> This MVP demonstrates the potential of decentralized language exchange on Solana. Contributions and forks are welcome!
